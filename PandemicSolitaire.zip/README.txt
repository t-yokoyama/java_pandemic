0. have java installed on your machine (jre 1.7 or better for best results).

1. extract the contents of PandemicSolitaire.zip into any directory (e.g. C:\Users\???\Desktop). this includes the .jar file and /external_files.

2. run a command prompt (cmd.exe on windows).

3. in the command prompt, move to the directory where the .rar file was extracted.
   'cd C:\Users\???\Desktop\'

4. execute the jar file via java.
   'java -jar PandemicSolitaire.jar'

5. play the game.

